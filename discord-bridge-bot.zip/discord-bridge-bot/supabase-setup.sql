-- Table relais entre FileDrop et Discord
-- (Déjà créée dans ton projet Supabase — ce fichier est juste une référence.)

create table if not exists bridge_messages (
  id bigint generated always as identity primary key,
  source text not null check (source in ('discord', 'filedrop')),
  author text not null,
  text text not null,
  created_at timestamptz not null default now()
);

alter table bridge_messages enable row level security;

-- Le site (clé publique) peut lire et écrire dans ce relais.
-- ⚠️ Ce n'est pas un salon privé : toute personne avec le lien du site peut lire/écrire ici.
create policy "public read bridge" on bridge_messages
  for select using (true);

create policy "public insert bridge" on bridge_messages
  for insert with check (source = 'filedrop');

-- Active le temps réel sur cette table
alter publication supabase_realtime add table bridge_messages;
